// app core loaded
