// sync core loaded
